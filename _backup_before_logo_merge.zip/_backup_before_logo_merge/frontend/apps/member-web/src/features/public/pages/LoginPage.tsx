import { PoweredByAtribsInline } from '@/components/brand/PoweredByAtribs';
import { ArrowLeft, ClipboardCheck, LockKeyhole, ShieldCheck } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { LoginForm } from "@/features/auth/components/LoginForm";
import { PublicCard, PublicShell } from "../components/PublicShell";
import { SethuLogo } from "@/components/brand/SethuLogo";

const assurances = [
  {
    icon: LockKeyhole,
    title: "Scoped access",
    detail:
      "Your workspace, role and organisational unit are resolved before protected actions.",
  },
  {
    icon: ShieldCheck,
    title: "Verified identity",
    detail:
      "Password and one-time-code sign-in paths are separated from visitor registration.",
  },
  {
    icon: ClipboardCheck,
    title: "Auditable work",
    detail: "Governed actions retain actor, role, reason and workflow context.",
  },
];

export default function LoginPage() {
  const [params] = useSearchParams();
  const returnTo = params.get("returnTo") ?? "";

  return (
    <PublicShell>
      <div className="mx-auto mb-4 max-w-6xl">
        <Link
          to="/"
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-sm font-bold text-slate-700 shadow-xs transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-950"
        >
          <ArrowLeft className="size-4 text-slate-600" />
          <span>Back</span>
        </Link>
      </div>
      <div className="mx-auto grid max-w-6xl gap-5 lg:grid-cols-[.9fr_1.1fr]">
        <section className="relative overflow-hidden rounded-3xl bg-[var(--navy-950)] p-7 text-white shadow-xl sm:p-9">
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-[radial-gradient(circle_at_85%_15%,rgba(14,165,233,.24),transparent_34%),linear-gradient(145deg,rgba(153,27,67,.24),transparent_42%)]"
          />
          <div className="relative">
            <SethuLogo className="size-16 rounded-full bg-white  object-contain shadow-md" />
            <div className="mt-8 text-sm font-black uppercase tracking-[.18em] text-sky-200">
              Secure workspace access
            </div>
            <h1 className="mt-3 text-4xl font-black leading-tight tracking-tight">
              Sign in to SETHU
            </h1>
            <p className="mt-4 max-w-md text-base leading-7 text-slate-300">
              Continue into the Bhandhu journey or an authorised organisational
              workspace with the correct effective role context.
            </p>
            <div className="mt-8 grid gap-3">
              {assurances.map((item) => (
                <div
                  key={item.title}
                  className="rounded-2xl border border-white/10 bg-white/[.07] p-4"
                >
                  <div className="flex items-start gap-3">
                    <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-sky-400/15 text-sky-200">
                      <item.icon className="size-5" />
                    </span>
                    <div>
                      <h2 className="font-black">{item.title}</h2>
                      <p className="mt-1 text-sm leading-6 text-slate-300">
                        {item.detail}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <PublicCard>
          <div className="mb-6">
            <div className="text-sm font-black uppercase tracking-[.16em] text-[var(--maroon-700)]">
              Account sign in
            </div>
            <h2 className="mt-2 text-2xl font-black text-[var(--navy-950)]">
              Use your authorised account
            </h2>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Member and office-bearer access remains separated from public
              visitor registration.
            </p>
          </div>
          <LoginForm returnTo={returnTo} />
          <PoweredByAtribsInline className="mt-6 pt-4 border-t border-slate-100" />
          {/* <div className="mt-5 flex flex-wrap justify-between gap-3 border-t border-slate-200 pt-4 text-sm">
            <Link className="font-bold text-sky-700" to={`/forgot-access${returnTo ? `?returnTo=${encodeURIComponent(returnTo)}` : ''}`}>Forgot access?</Link>
            <Link className="font-bold text-sky-700" to="/visitor/register">New visitor registration</Link>
          </div> */}
        </PublicCard>
      </div>
    </PublicShell>
  );
}
