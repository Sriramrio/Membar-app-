import { useState, type FormEvent } from 'react';
import { ShieldAlert, Lock, KeyRound, Server, ShieldCheck, ArrowRight, CheckCircle2, AlertTriangle, Eye, EyeOff } from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAppDispatch } from '@/app/hooks';
import { authenticateAccount, selectWorkspace } from '@/features/auth/authSlice';
import { loginPlatform } from '@/features/auth/authService';

export default function PlatformLoginPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const returnTo = params.get('returnTo') || '/platform-admin/dashboard';
  const accessDenied = params.get('denied') === '1';

  const [identifier, setIdentifier] = useState('platformadmin@dbn.network');
  const [password, setPassword] = useState('Platform@123456');
  const [pin, setPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function handleLogin(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (!identifier.trim() || !password) {
      setError('Please provide operator identifier and authorization key.');
      return;
    }

    setBusy(true);
    try {
      const account = await loginPlatform(identifier.trim(), password);
      dispatch(authenticateAccount(account));
      dispatch(selectWorkspace('Platform Admin'));
      navigate(returnTo, { replace: true });
    } catch (err: any) {
      setError(err?.detail || err?.title || 'Unable to authenticate operator. Check credentials.');
    } finally {
      setBusy(false);
    }
  }

  function handleDemoCredentials(type: 'admin' | 'security') {
    if (type === 'admin') {
      setIdentifier('platform.admin@sethu.local');
      setPassword('Platform@123456');
    } else {
      setIdentifier('sec-lead@sethu.local');
      setPassword('Platform@123456');
    }
    setError('');
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-sky-500 selection:text-white">
      {/* Top Banner / Navigation */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/brand/sethu-logo.jpeg" alt="DBN SETHU" className="h-10 w-auto rounded-lg bg-white p-0.5 object-contain" />
            <div>
              <div className="text-xs font-bold uppercase tracking-widest text-sky-400">Dharmic Business Network</div>
              <div className="text-base font-extrabold text-white tracking-tight">Platform Administration Hub</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <span className="size-2 rounded-full bg-emerald-400 animate-pulse" />
              Operational Gateway v7.1
            </span>
            <Link
              to="/login"
              className="text-xs font-semibold text-slate-400 hover:text-sky-300 transition-colors px-3 py-1.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900/80"
            >
              Member Portal &rarr;
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-4xl grid lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Security Context Panel */}
          <div className="lg:col-span-5 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-500/10 text-rose-300 border border-rose-500/20">
              <ShieldAlert className="size-3.5 text-rose-400" />
              Restricted Operations Area
            </div>

            <div>
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white leading-tight">
                Authorised Platform Operator Sign In
              </h1>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">
                You are entering the central SETHU management and governance plane. This console regulates multi-tenant identities, RBAC, RACI policies, schema synchronization, and system audits.
              </p>
            </div>

            {accessDenied && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-sm flex items-start gap-3">
                <AlertTriangle className="size-5 shrink-0 text-amber-400 mt-0.5" />
                <div>
                  <div className="font-bold">Access Escalation Required</div>
                  <div className="text-xs text-amber-400/90 mt-0.5">
                    Your current session lacks the Platform Admin privilege required for this resource. Sign in with an authorised operator account below.
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-3 pt-2">
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs space-y-1">
                <div className="font-semibold text-slate-200 flex items-center gap-2">
                  <ShieldCheck className="size-4 text-sky-400" />
                  Canonical Role Enforced
                </div>
                <div className="text-slate-400">All actions are recorded in immutable audit logs with cryptographic operator attribution.</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs space-y-1">
                <div className="font-semibold text-slate-200 flex items-center gap-2">
                  <Server className="size-4 text-emerald-400" />
                  Multi-Tenant Separation
                </div>
                <div className="text-slate-400">Cross-tenant boundaries, Parivar registries, and core data quality controls.</div>
              </div>
            </div>
          </div>

          {/* Right Login Card */}
          <div className="lg:col-span-7">
            <div className="relative rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
              <div className="flex items-center justify-between pb-6 border-b border-slate-800">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-sky-400">Console Authentication</div>
                  <h2 className="text-xl font-black text-white mt-0.5">Operator Credentials</h2>
                </div>
                <div className="size-10 rounded-xl bg-sky-500/10 border border-sky-500/20 grid place-items-center text-sky-400">
                  <Lock className="size-5" />
                </div>
              </div>

              {error && (
                <div className="mt-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2 font-medium">
                  <AlertTriangle className="size-4 text-rose-400 shrink-0" />
                  {error}
                </div>
              )}

              <form onSubmit={handleLogin} className="mt-6 space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Operator ID / Email
                  </label>
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="platform.admin@sethu.local"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-colors text-sm font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Authorization Secret
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter administrator password"
                      className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-colors text-sm font-medium pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                    >
                      {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between">
                    <span>MFA / Security Token (Optional)</span>
                    <span className="text-[10px] text-slate-500 font-normal">If enrolled</span>
                  </label>
                  <input
                    type="password"
                    maxLength={8}
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="6-digit authenticator code"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-colors text-sm font-mono tracking-widest"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={busy}
                    className="w-full py-3.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-sm tracking-wide transition-all shadow-lg shadow-sky-500/20 hover:shadow-sky-500/30 active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {busy ? (
                      <span className="inline-flex items-center gap-2">
                        <span className="size-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        Verifying Operator Context…
                      </span>
                    ) : (
                      <>
                        <span>Enter Platform Administration</span>
                        <ArrowRight className="size-4" />
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* Developer / Demo Quick-fill Controls */}
              <div className="mt-6 pt-5 border-t border-slate-800/80">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Evaluation Quick Credentials
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => handleDemoCredentials('admin')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-xs font-medium text-slate-300 transition-colors flex items-center gap-1.5"
                  >
                    <KeyRound className="size-3 text-sky-400" />
                    Load Platform Admin
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDemoCredentials('security')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-xs font-medium text-slate-300 transition-colors flex items-center gap-1.5"
                  >
                    <ShieldCheck className="size-3 text-emerald-400" />
                    Load Security Lead
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-6 py-4 text-center text-xs text-slate-500">
        <p>&copy; 2026 Dharmic Business Network (DBN) — SETHU Platform Architecture. Restricted to authorized administrators.</p>
      </footer>
    </div>
  );
}
