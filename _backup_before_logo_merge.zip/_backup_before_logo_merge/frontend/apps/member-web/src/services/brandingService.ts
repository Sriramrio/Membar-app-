import { useState, useEffect } from 'react';

export interface SystemBranding {
  sidebarLogo: string | null;
  headerLogo: string | null;
  updatedAt?: string | null;
}

export interface ChapterBranding {
  id?: string;
  name: string;
  image?: string | null;
  logo?: string | null;
}

const SYSTEM_BRANDING_KEY = 'sethu:system-branding';
const CHAPTER_BRANDING_KEY = 'sethu:chapter-branding';
const BRANDING_EVENT = 'sethu:branding:changed';

export const DEFAULT_BRANDING = {
  sidebarLogo: '/brand/sethu-logo.jpeg',
  headerLogo: '/brand/dbn-logo.jpeg',
  chapterLogo: '/brand/Chapter-logo.jpeg',
};

function readLocalStorage<T>(key: string, defaultValue: T): T {
  try {
    if (typeof localStorage === 'undefined') return defaultValue;
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw) as T;
  } catch {
    return defaultValue;
  }
}

function writeLocalStorage<T>(key: string, value: T): void {
  try {
    if (typeof localStorage === 'undefined') return;
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn(`Failed to write to localStorage for key ${key}:`, e);
  }
}

function notifyBrandingChange(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(BRANDING_EVENT));
  }
}

export const brandingService = {
  // 1. System Branding
  getSystemBranding(): SystemBranding {
    return readLocalStorage<SystemBranding>(SYSTEM_BRANDING_KEY, {
      sidebarLogo: null,
      headerLogo: null,
    });
  },

  async syncSystemBrandingFromBackend(): Promise<SystemBranding> {
    try {
      const res = await fetch('/api/system-settings/branding');
      if (res.ok) {
        const data = await res.json();
        if (data) {
          const current = this.getSystemBranding();
          const next: SystemBranding = {
            sidebarLogo: data.sidebarLogo ?? current.sidebarLogo,
            headerLogo: data.headerLogo ?? current.headerLogo,
            updatedAt: data.updatedAt ?? new Date().toISOString(),
          };
          writeLocalStorage(SYSTEM_BRANDING_KEY, next);
          notifyBrandingChange();
          return next;
        }
      }
    } catch {
      // Backend offline or mock - local cache remains active
    }
    return this.getSystemBranding();
  },

  async saveSystemBranding(branding: Partial<SystemBranding>): Promise<SystemBranding> {
    const current = this.getSystemBranding();
    const updated: SystemBranding = {
      sidebarLogo: branding.sidebarLogo !== undefined ? branding.sidebarLogo : current.sidebarLogo,
      headerLogo: branding.headerLogo !== undefined ? branding.headerLogo : current.headerLogo,
      updatedAt: new Date().toISOString(),
    };

    // Save locally first for instant reactive update
    writeLocalStorage(SYSTEM_BRANDING_KEY, updated);
    notifyBrandingChange();

    // Persist to backend database API
    try {
      const payload = {
        sidebarLogo: branding.sidebarLogo === null ? '__RESET__' : (branding.sidebarLogo !== undefined ? branding.sidebarLogo : undefined),
        headerLogo: branding.headerLogo === null ? '__RESET__' : (branding.headerLogo !== undefined ? branding.headerLogo : undefined),
      };
      await fetch('/api/system-settings/branding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    } catch (err) {
      console.warn('Backend database sync for system branding fallback to local store:', err);
    }

    return updated;
  },

  async resetSystemBranding(): Promise<void> {
    const empty: SystemBranding = {
      sidebarLogo: null,
      headerLogo: null,
      updatedAt: new Date().toISOString(),
    };
    writeLocalStorage(SYSTEM_BRANDING_KEY, empty);
    notifyBrandingChange();

    try {
      await fetch('/api/system-settings/branding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(empty),
      });
    } catch (err) {
      console.warn('Backend database sync for system branding reset fallback to local store:', err);
    }
  },

  // 2. Chapter Branding
  getAllChapterBranding(): Record<string, ChapterBranding> {
    return readLocalStorage<Record<string, ChapterBranding>>(CHAPTER_BRANDING_KEY, {});
  },

  async syncChaptersFromBackend(): Promise<Record<string, ChapterBranding>> {
    try {
      const res = await fetch('/api/chapters?all=true');
      if (res.ok) {
        const list = await res.json();
        if (Array.isArray(list)) {
          const all = this.getAllChapterBranding();
          for (const ch of list) {
            const img = ch.image || ch.logo;
            const logo = ch.logo || ch.image;
            if (img || logo) {
              const chapterData: ChapterBranding = {
                id: ch.id,
                name: ch.name || '',
                image: img,
                logo: logo,
              };
              if (ch.id) all[ch.id.toLowerCase()] = chapterData;
              if (ch.name) {
                const cleanName = ch.name.trim().toLowerCase();
                all[cleanName] = chapterData;
                const stripped = cleanName.replace(/\b(chapter|parivar)\b/gi, '').trim();
                if (stripped && stripped !== cleanName) {
                  all[stripped] = chapterData;
                }
              }
            }
          }
          writeLocalStorage(CHAPTER_BRANDING_KEY, all);
          notifyBrandingChange();
          return all;
        }
      }
    } catch (e) {
      console.warn('Backend sync for chapter branding failed:', e);
    }
    return this.getAllChapterBranding();
  },

  getChapterBranding(chapterIdentifier?: string | null): ChapterBranding | null {
    if (!chapterIdentifier) return null;
    const all = this.getAllChapterBranding();
    const rawKey = chapterIdentifier.trim().toLowerCase();

    // 1. Direct match on key, id, or name
    if (all[rawKey]) return all[rawKey];
    for (const item of Object.values(all)) {
      if (
        (item.id && item.id.toLowerCase() === rawKey) ||
        (item.name && item.name.toLowerCase() === rawKey)
      ) {
        return item;
      }
    }

    // 2. Normalized match (without 'chapter', 'parivar')
    const strippedKey = rawKey.replace(/\b(chapter|parivar)\b/gi, '').trim();
    if (strippedKey && all[strippedKey]) return all[strippedKey];

    // 3. Substring match
    for (const item of Object.values(all)) {
      const itemName = (item.name || '').toLowerCase();
      const itemStripped = itemName.replace(/\b(chapter|parivar)\b/gi, '').trim();
      if (
        (strippedKey && itemStripped && (strippedKey.includes(itemStripped) || itemStripped.includes(strippedKey))) ||
        (strippedKey && itemName.includes(strippedKey)) ||
        (itemStripped && rawKey.includes(itemStripped))
      ) {
        return item;
      }
    }

    return null;
  },

  saveChapterBranding(branding: {
    chapterId?: string;
    name: string;
    image?: string | null;
    logo?: string | null;
  }): ChapterBranding {
    const all = this.getAllChapterBranding();
    const normalizedName = branding.name.trim().toLowerCase();
    const strippedName = normalizedName.replace(/\b(chapter|parivar)\b/gi, '').trim();
    const chapterData: ChapterBranding = {
      id: branding.chapterId,
      name: branding.name.trim(),
      image: branding.image ?? branding.logo ?? null,
      logo: branding.logo ?? branding.image ?? null,
    };

    all[normalizedName] = chapterData;
    if (strippedName && strippedName !== normalizedName) {
      all[strippedName] = chapterData;
    }
    if (branding.chapterId) {
      all[branding.chapterId.toLowerCase()] = chapterData;
    }

    writeLocalStorage(CHAPTER_BRANDING_KEY, all);
    notifyBrandingChange();
    return chapterData;
  },
};

// React Hook to subscribe to System Branding updates
export function useSystemBranding(): SystemBranding {
  const [branding, setBranding] = useState<SystemBranding>(() => brandingService.getSystemBranding());

  useEffect(() => {
    // Initial fetch from backend if available
    brandingService.syncSystemBrandingFromBackend().then(setBranding).catch(() => {});

    const handler = () => {
      setBranding(brandingService.getSystemBranding());
    };

    window.addEventListener(BRANDING_EVENT, handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener(BRANDING_EVENT, handler);
      window.removeEventListener('storage', handler);
    };
  }, []);

  return branding;
}

// React Hook to subscribe to Chapter Branding updates
export function useChapterBranding(chapterIdentifier?: string | null): ChapterBranding | null {
  const [branding, setBranding] = useState<ChapterBranding | null>(() =>
    brandingService.getChapterBranding(chapterIdentifier)
  );

  useEffect(() => {
    const local = brandingService.getChapterBranding(chapterIdentifier);
    if (local) setBranding(local);

    // Active sync from backend to get fresh database branding
    brandingService.syncChaptersFromBackend().then(() => {
      setBranding(brandingService.getChapterBranding(chapterIdentifier));
    }).catch(() => {});

    const handler = () => {
      setBranding(brandingService.getChapterBranding(chapterIdentifier));
    };

    window.addEventListener(BRANDING_EVENT, handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener(BRANDING_EVENT, handler);
      window.removeEventListener('storage', handler);
    };
  }, [chapterIdentifier]);

  return branding;
}
