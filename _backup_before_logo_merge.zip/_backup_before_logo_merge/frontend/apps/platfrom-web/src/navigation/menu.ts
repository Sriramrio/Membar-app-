import {routes} from '@/routes/routeManifest';
import {filterVisibleRoutes} from '@sethu/navigation';
export const menuGroups=['Overview','Platform','Organisation','Identity & Access','Business Definitions','Communication','Integrations','Platform Operations','Assurance','System','Intelligence'] as const;
export function menuFor(permissions:string[]){const visibleRoutes=filterVisibleRoutes(routes,permissions);return menuGroups.map(group=>({group,items:visibleRoutes.filter(r=>r.group===group)})).filter(g=>g.items.length)}
