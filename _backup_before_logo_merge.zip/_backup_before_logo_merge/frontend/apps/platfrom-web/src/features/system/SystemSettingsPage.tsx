import { useState } from 'react';
import { PageHeader, Card, Pill } from '@/components/Ui';
import { LucideIcon } from '@/components/LucideIcon';
import { fileToWebpBase64 } from '@/utils/imageToWebp';
import {
  brandingService,
  useSystemBranding,
  DEFAULT_BRANDING,
} from '@/services/brandingService';

export function SystemSettingsPage() {
  const branding = useSystemBranding();

  const [sidebarLogoDraft, setSidebarLogoDraft] = useState<string | null>(null);
  const [headerLogoDraft, setHeaderLogoDraft] = useState<string | null>(null);
  const [processingSidebar, setProcessingSidebar] = useState(false);
  const [processingHeader, setProcessingHeader] = useState(false);
  const [savingSidebar, setSavingSidebar] = useState(false);
  const [savingHeader, setSavingHeader] = useState(false);
  const [notice, setNotice] = useState<{ msg: string; tone: 'good' | 'bad' | 'warn' } | null>(null);

  const notify = (msg: string, tone: 'good' | 'bad' | 'warn' = 'good') => {
    setNotice({ msg, tone });
    setTimeout(() => setNotice(null), 5000);
  };

  // Upload handler for Sidebar Logo
  const handleSidebarLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setProcessingSidebar(true);
      const webp = await fileToWebpBase64(file, { maxWidth: 400, maxHeight: 400, quality: 0.85 });
      setSidebarLogoDraft(webp);
      notify('Sidebar Sethu logo converted to Base64 WebP! Click "Save to Database & Apply" to activate.', 'good');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to process sidebar logo.', 'bad');
    } finally {
      setProcessingSidebar(false);
    }
  };

  // Upload handler for Header Logo
  const handleHeaderLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setProcessingHeader(true);
      const webp = await fileToWebpBase64(file, { maxWidth: 600, maxHeight: 200, quality: 0.85 });
      setHeaderLogoDraft(webp);
      notify('Navbar Dharmic logo converted to Base64 WebP! Click "Save to Database & Apply" to activate.', 'good');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to process header logo.', 'bad');
    } finally {
      setProcessingHeader(false);
    }
  };

  // Save Sidebar Logo
  const handleSaveSidebarLogo = async () => {
    if (!sidebarLogoDraft) return;
    try {
      setSavingSidebar(true);
      await brandingService.saveSystemBranding({ sidebarLogo: sidebarLogoDraft });
      setSidebarLogoDraft(null);
      notify('Org Logo updated in PostgreSQL database and applied system-wide!', 'good');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save Org Logo.', 'bad');
    } finally {
      setSavingSidebar(false);
    }
  };

  // Reset Sidebar Logo to Default
  const handleResetSidebarLogo = async () => {
    try {
      setSavingSidebar(true);
      await brandingService.saveSystemBranding({ sidebarLogo: null });
      setSidebarLogoDraft(null);
      notify('Org Logo reset to default /brand/sethu-logo.jpeg in database.', 'warn');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to reset Org Logo.', 'bad');
    } finally {
      setSavingSidebar(false);
    }
  };

  // Save Header Logo
  const handleSaveHeaderLogo = async () => {
    if (!headerLogoDraft) return;
    try {
      setSavingHeader(true);
      await brandingService.saveSystemBranding({ headerLogo: headerLogoDraft });
      setHeaderLogoDraft(null);
      notify('Header Logo updated in PostgreSQL database and applied system-wide!', 'good');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save Header Logo.', 'bad');
    } finally {
      setSavingHeader(false);
    }
  };

  // Reset Header Logo to Default
  const handleResetHeaderLogo = async () => {
    try {
      setSavingHeader(true);
      await brandingService.saveSystemBranding({ headerLogo: null });
      setHeaderLogoDraft(null);
      notify('Header Logo reset to default /brand/dbn-logo.jpeg in database.', 'warn');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to reset Header Logo.', 'bad');
    } finally {
      setSavingHeader(false);
    }
  };

  const activeSidebarLogo = sidebarLogoDraft || branding.sidebarLogo || DEFAULT_BRANDING.sidebarLogo;
  const isCustomSidebar = Boolean(sidebarLogoDraft || branding.sidebarLogo);

  const activeHeaderLogo = headerLogoDraft || branding.headerLogo || DEFAULT_BRANDING.headerLogo;
  const isCustomHeader = Boolean(headerLogoDraft || branding.headerLogo);

  return (
    <div className="stack" style={{ gap: '20px' }}>
      <PageHeader
        title="System Settings & Brand Management"
        description="Configure enterprise platform logos and visual identity. Changes are converted to Base64 WebP format, persisted to PostgreSQL database, and immediately reflected across the Sidebar and Navbar header."
      />

      {notice && (
        <div
          className={`notice ${notice.tone === 'good' ? 'success' : notice.tone === 'bad' ? 'error' : 'warn'}`}
          style={{
            padding: '12px 16px',
            borderRadius: '8px',
            background: notice.tone === 'good' ? '#ecfdf5' : notice.tone === 'bad' ? '#fef2f2' : '#fffbeb',
            border: `1px solid ${notice.tone === 'good' ? '#a7f3d0' : notice.tone === 'bad' ? '#fecaca' : '#fde68a'}`,
            color: notice.tone === 'good' ? '#065f46' : notice.tone === 'bad' ? '#991b1b' : '#92400e',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '13px',
            fontWeight: '600'
          }}
        >
          <LucideIcon name={notice.tone === 'good' ? 'check' : 'alert-triangle'} size={18} />
          <span>{notice.msg}</span>
        </div>
      )}

      <div className="grid grid-2" style={{ gap: '24px' }}>
        {/* =========================================================
            CARD 1: SIDEBAR SETHU LOGO
           ========================================================= */}
        <section className="exec-card" style={{ padding: '24px', background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #e2e8f0', paddingBottom: '16px', marginBottom: '18px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '8px', background: '#eff6ff', color: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <LucideIcon name="sliders-horizontal" size={20} />
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>Org Logo</h3>
                <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#64748b' }}>Reflects in the Sidebar navigation brand header across Member, Organisation and Platform (Base64 WebP)</p>
              </div>
            </div>
            {isCustomSidebar && (
              <span style={{ fontSize: '11px', fontWeight: '700', color: '#059669', background: '#ecfdf5', border: '1px solid #a7f3d0', padding: '2px 8px', borderRadius: '9999px' }}>
                Customized
              </span>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {/* Live Preview Box */}
            <div>
              <div style={{ fontSize: '11px', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <LucideIcon name="eye" size={14} />
                <span>Org Logo Live Simulation</span>
              </div>
              <div style={{ background: '#0a1020', padding: '14px 16px', borderRadius: '10px', display: 'flex', alignItems: 'center', gap: '12px', border: '1px solid #1e293b' }}>
                <img
                  src={activeSidebarLogo}
                  alt="Org Logo Preview"
                  style={{ width: '36px', height: '36px', borderRadius: '8px', objectFit: 'contain', background: '#ffffff', padding: '2px', flexShrink: 0 }}
                />
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ fontSize: '14px', fontWeight: '900', color: '#ffffff' }}>SETHU</span>
                    <span style={{ fontSize: '9px', fontWeight: '800', color: '#fbbf24', background: 'rgba(251,191,36,0.15)', border: '1px solid rgba(251,191,36,0.3)', padding: '1px 5px', borderRadius: '3px', textTransform: 'uppercase' }}>
                      Admin
                    </span>
                  </div>
                  <div style={{ fontSize: '10px', color: '#94a3b8' }}>Dharmic Business Network</div>
                </div>
              </div>
            </div>

            {/* Upload & Action Controls */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <label style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '9px 16px', borderRadius: '8px', background: '#2563eb', color: '#ffffff', fontSize: '13px', fontWeight: '600', cursor: 'pointer', transition: 'background 0.15s ease' }}>
                  <LucideIcon name="upload" size={15} />
                  <span>{processingSidebar ? 'Converting to WebP…' : 'Choose New Org Logo'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    disabled={processingSidebar || savingSidebar}
                    onChange={handleSidebarLogoUpload}
                    style={{ display: 'none' }}
                  />
                </label>

                {sidebarLogoDraft && (
                  <button
                    type="button"
                    onClick={handleSaveSidebarLogo}
                    disabled={savingSidebar}
                    style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 16px', borderRadius: '8px', background: '#059669', color: '#ffffff', fontSize: '13px', fontWeight: '600', border: 'none', cursor: 'pointer' }}
                  >
                    <LucideIcon name="check" size={15} />
                    <span>{savingSidebar ? 'Saving…' : 'Save to Database & Apply'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleResetSidebarLogo}
                  disabled={savingSidebar || !branding.sidebarLogo}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 14px', borderRadius: '8px', background: '#f8fafc', color: '#64748b', fontSize: '13px', fontWeight: '500', border: '1px solid #cbd5e1', cursor: branding.sidebarLogo ? 'pointer' : 'not-allowed', opacity: branding.sidebarLogo ? 1 : 0.6 }}
                  title="Reset to default /brand/sethu-logo.jpeg"
                >
                  <LucideIcon name="refresh-cw" size={14} />
                  <span>Reset to Default</span>
                </button>
              </div>

              {sidebarLogoDraft && (
                <div style={{ fontSize: '12px', color: '#059669', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: '500' }}>
                  <LucideIcon name="check" size={14} />
                  <span>Draft logo ready in WebP format. Click "Save to Database & Apply" to persist.</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* =========================================================
            CARD 2: NAVBAR DHARMIC LOGO (DBN)
           ========================================================= */}
        <section className="exec-card" style={{ padding: '24px', background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #e2e8f0', paddingBottom: '16px', marginBottom: '18px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '8px', background: '#fef3c7', color: '#d97706', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <LucideIcon name="sliders-horizontal" size={20} />
              </div>
              <div>
                <h3 style={{ margin: 0, fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>Header Logo</h3>
                <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#64748b' }}>Reflects in the top header navbar right section across Member, Organisation and Platform (Base64 WebP)</p>
              </div>
            </div>
            {isCustomHeader && (
              <span style={{ fontSize: '11px', fontWeight: '700', color: '#059669', background: '#ecfdf5', border: '1px solid #a7f3d0', padding: '2px 8px', borderRadius: '9999px' }}>
                Customized
              </span>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {/* Live Preview Box */}
            <div>
              <div style={{ fontSize: '11px', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <LucideIcon name="eye" size={14} />
                <span>Header Logo Live Simulation</span>
              </div>
              <div style={{ background: '#f8fafc', padding: '14px 16px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', border: '1px solid #e2e8f0' }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '12px', fontWeight: 700, color: '#047857', background: '#ecfdf5', border: '1px solid #a7f3d0', padding: '3px 10px', borderRadius: '9999px' }}>
                  <span style={{ width: '7px', height: '7px', borderRadius: '50%', backgroundColor: '#10b981' }}></span>
                  Platform Administration Console
                </span>
                <img
                  src={activeHeaderLogo}
                  alt="Header Logo Preview"
                  style={{ height: '32px', width: 'auto', maxHeight: '36px', objectFit: 'contain', background: '#ffffff', padding: '2px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                />
              </div>
            </div>

            {/* Upload & Action Controls */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <label style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '9px 16px', borderRadius: '8px', background: '#d97706', color: '#ffffff', fontSize: '13px', fontWeight: '600', cursor: 'pointer', transition: 'background 0.15s ease' }}>
                  <LucideIcon name="upload" size={15} />
                  <span>{processingHeader ? 'Converting to WebP…' : 'Choose New Header Logo'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    disabled={processingHeader || savingHeader}
                    onChange={handleHeaderLogoUpload}
                    style={{ display: 'none' }}
                  />
                </label>

                {headerLogoDraft && (
                  <button
                    type="button"
                    onClick={handleSaveHeaderLogo}
                    disabled={savingHeader}
                    style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 16px', borderRadius: '8px', background: '#059669', color: '#ffffff', fontSize: '13px', fontWeight: '600', border: 'none', cursor: 'pointer' }}
                  >
                    <LucideIcon name="check" size={15} />
                    <span>{savingHeader ? 'Saving…' : 'Save to Database & Apply'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleResetHeaderLogo}
                  disabled={savingHeader || !branding.headerLogo}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 14px', borderRadius: '8px', background: '#f8fafc', color: '#64748b', fontSize: '13px', fontWeight: '500', border: '1px solid #cbd5e1', cursor: branding.headerLogo ? 'pointer' : 'not-allowed', opacity: branding.headerLogo ? 1 : 0.6 }}
                  title="Reset to default /brand/dbn-logo.jpeg"
                >
                  <LucideIcon name="refresh-cw" size={14} />
                  <span>Reset to Default</span>
                </button>
              </div>

              {headerLogoDraft && (
                <div style={{ fontSize: '12px', color: '#059669', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: '500' }}>
                  <LucideIcon name="check" size={14} />
                  <span>Draft logo ready in WebP format. Click "Save to Database & Apply" to persist.</span>
                </div>
              )}
            </div>
          </div>
        </section>
      </div>

      {/* Persistence Architecture & Safeguards Card */}
      <section style={{ padding: '16px 20px', background: '#f8fafc', borderRadius: '10px', border: '1px solid #e2e8f0' }}>
        <div style={{ fontSize: '13px', fontWeight: '700', color: '#1e293b', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <LucideIcon name="shield" size={16} style={{ color: '#2563eb' }} />
          <span>System Branding Persistence &amp; Integrity Guarantee</span>
        </div>
        <div style={{ fontSize: '12px', color: '#475569', lineHeight: '1.6', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '12px' }}>
          <div>
            <strong>1. WebP Compression:</strong> All logos are scaled and compressed client-side to WebP to ensure fast transmission and low database footprint.
          </div>
          <div>
            <strong>2. PostgreSQL Storage:</strong> Branding is saved to the <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>system_branding</code> table in the backend database.
          </div>
          <div>
            <strong>3. Graceful Fallbacks:</strong> If custom branding is removed, the system seamlessly falls back to default assets <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>/brand/sethu-logo.jpeg</code> and <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>/brand/dbn-logo.jpeg</code>.
          </div>
        </div>
      </section>
    </div>
  );
}

