using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sethu.Domain.Entities;
using Sethu.Infrastructure.Persistence;

namespace Sethu.Api.Controllers;

public record BrandingSettingsDto(string? SidebarLogo, string? HeaderLogo, DateTimeOffset? UpdatedAt);

[ApiController]
[Authorize]
[TypeFilter(typeof(Sethu.Api.Security.LegacyPrivilegedBoundaryFilter))]
[Route("api/system-settings")]
[Route("system-settings")]
public class SystemSettingsController : ControllerBase
{
    private readonly SethuDbContext _db;
    private readonly IWebHostEnvironment _env;
    private readonly ILogger<SystemSettingsController> _logger;
    private static readonly object FileLock = new();

    public SystemSettingsController(SethuDbContext db, IWebHostEnvironment env, ILogger<SystemSettingsController> logger)
    {
        _db = db;
        _env = env;
        _logger = logger;
    }

    private string CacheFilePath => Path.Combine(_env.ContentRootPath, "system-branding.json");

    [AllowAnonymous]
    [HttpGet("branding")]
    public async Task<IActionResult> GetBranding(CancellationToken ct)
    {
        try
        {
            var record = await _db.SystemBrandings.AsNoTracking().FirstOrDefaultAsync(x => x.Id == "default", ct);
            if (record != null)
            {
                return Ok(new BrandingSettingsDto(record.SidebarLogo, record.HeaderLogo, record.UpdatedAt));
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Database system_branding read fallback to disk cache");
        }

        // Fallback to local file cache
        if (System.IO.File.Exists(CacheFilePath))
        {
            try
            {
                lock (FileLock)
                {
                    var json = System.IO.File.ReadAllText(CacheFilePath);
                    var cached = JsonSerializer.Deserialize<BrandingSettingsDto>(json);
                    if (cached != null) return Ok(cached);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to read branding file cache");
            }
        }

        return Ok(new BrandingSettingsDto(null, null, null));
    }

    [HttpPost("branding")]
    public async Task<IActionResult> SaveBranding([FromBody] BrandingSettingsDto dto, CancellationToken ct)
    {
        var now = DateTimeOffset.UtcNow;
        string? finalSidebar = null;
        string? finalHeader = null;

        // 1. Persist to DB table via EF Core
        try
        {
            var record = await _db.SystemBrandings.FirstOrDefaultAsync(x => x.Id == "default", ct);
            if (record == null)
            {
                record = new SystemBranding
                {
                    Id = "default",
                    SidebarLogo = dto.SidebarLogo == "__RESET__" ? null : dto.SidebarLogo,
                    HeaderLogo = dto.HeaderLogo == "__RESET__" ? null : dto.HeaderLogo,
                    UpdatedAt = now
                };
                _db.SystemBrandings.Add(record);
            }
            else
            {
                if (dto.SidebarLogo != null)
                {
                    record.SidebarLogo = dto.SidebarLogo == "__RESET__" ? null : dto.SidebarLogo;
                }
                if (dto.HeaderLogo != null)
                {
                    record.HeaderLogo = dto.HeaderLogo == "__RESET__" ? null : dto.HeaderLogo;
                }
                record.UpdatedAt = now;
            }

            await _db.SaveChangesAsync(ct);
            finalSidebar = record.SidebarLogo;
            finalHeader = record.HeaderLogo;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Branding database update failed; no successful update will be reported.");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new { code = "BRANDING_PERSISTENCE_FAILED" });
        }

        var result = new BrandingSettingsDto(finalSidebar ?? dto.SidebarLogo, finalHeader ?? dto.HeaderLogo, now);

        // 2. Persist to file cache for durability
        try
        {
            lock (FileLock)
            {
                var json = JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
                System.IO.File.WriteAllText(CacheFilePath, json);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Could not save branding to disk cache");
        }

        return Ok(result);
    }
}

