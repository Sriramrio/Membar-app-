﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Sethu.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddBusinessTaxonomyAndProfileColumns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "SectorId",
                schema: "public",
                table: "dbn_member_registrations",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SectorName",
                schema: "public",
                table: "dbn_member_registrations",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "SegmentId",
                schema: "public",
                table: "dbn_member_registrations",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SegmentName",
                schema: "public",
                table: "dbn_member_registrations",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "SpecialisationId",
                schema: "public",
                table: "dbn_member_registrations",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SpecialisationName",
                schema: "public",
                table: "dbn_member_registrations",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "image",
                schema: "public",
                table: "chapters",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "logo",
                schema: "public",
                table: "chapters",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "action_reason",
                schema: "public",
                table: "chapter_leaders",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "relieved_at",
                schema: "public",
                table: "chapter_leaders",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "suspended_at",
                schema: "public",
                table: "chapter_leaders",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "event_rsvps",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    EventId = table.Column<Guid>(type: "uuid", nullable: false),
                    MemberId = table.Column<string>(type: "text", nullable: false),
                    MemberName = table.Column<string>(type: "text", nullable: false),
                    MemberEmail = table.Column<string>(type: "text", nullable: false),
                    MemberPhone = table.Column<string>(type: "text", nullable: false),
                    ChapterId = table.Column<string>(type: "text", nullable: true),
                    ChapterName = table.Column<string>(type: "text", nullable: true),
                    Status = table.Column<string>(type: "text", nullable: false),
                    SubstituteName = table.Column<string>(type: "text", nullable: true),
                    SubstitutePhone = table.Column<string>(type: "text", nullable: true),
                    Notes = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_event_rsvps", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "membership_registration_links",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    ChapterId = table.Column<Guid>(type: "uuid", nullable: false),
                    RegistrationId = table.Column<Guid>(type: "uuid", nullable: false),
                    IntakeId = table.Column<Guid>(type: "uuid", nullable: false),
                    ApplicantUserId = table.Column<Guid>(type: "uuid", nullable: false),
                    ReviewerUserId = table.Column<Guid>(type: "uuid", nullable: false),
                    EvidenceReference = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: false),
                    ReviewedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_membership_registration_links", x => x.Id);
                    table.ForeignKey(
                        name: "FK_membership_registration_links_dbn_member_registrations_Regi~",
                        column: x => x.RegistrationId,
                        principalSchema: "public",
                        principalTable: "dbn_member_registrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_membership_registration_links_member_intakes_IntakeId",
                        column: x => x.IntakeId,
                        principalSchema: "public",
                        principalTable: "member_intakes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "organisation_handovers",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    AssignmentId = table.Column<string>(type: "text", nullable: false),
                    OutgoingMemberId = table.Column<string>(type: "text", nullable: false),
                    IncomingMemberId = table.Column<string>(type: "text", nullable: false),
                    ScopeId = table.Column<string>(type: "text", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: false),
                    PreparedAt = table.Column<string>(type: "text", nullable: false),
                    AcceptedAt = table.Column<string>(type: "text", nullable: true),
                    CompletedAt = table.Column<string>(type: "text", nullable: true),
                    OpenTaskIdsJson = table.Column<string>(type: "text", nullable: false),
                    OpenActionIdsJson = table.Column<string>(type: "text", nullable: false),
                    OpenCaseIdsJson = table.Column<string>(type: "text", nullable: false),
                    MeetingIdsJson = table.Column<string>(type: "text", nullable: false),
                    ProgrammeIdsJson = table.Column<string>(type: "text", nullable: false),
                    DocumentIdsJson = table.Column<string>(type: "text", nullable: false),
                    SummaryJson = table.Column<string>(type: "text", nullable: true),
                    Version = table.Column<long>(type: "bigint", nullable: false),
                    CreatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_organisation_handovers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "system_branding",
                schema: "public",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    sidebar_logo = table.Column<string>(type: "text", nullable: true),
                    header_logo = table.Column<string>(type: "text", nullable: true),
                    updated_at = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_system_branding", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "visitor_conversion_credits",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    ChapterId = table.Column<Guid>(type: "uuid", nullable: false),
                    RegistrationId = table.Column<Guid>(type: "uuid", nullable: false),
                    IntakeId = table.Column<Guid>(type: "uuid", nullable: false),
                    MemberId = table.Column<Guid>(type: "uuid", nullable: false),
                    InvitationId = table.Column<Guid>(type: "uuid", nullable: false),
                    InviterMemberId = table.Column<Guid>(type: "uuid", nullable: false),
                    ActivatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_visitor_conversion_credits", x => x.Id);
                    table.ForeignKey(
                        name: "FK_visitor_conversion_credits_member_intakes_IntakeId",
                        column: x => x.IntakeId,
                        principalSchema: "public",
                        principalTable: "member_intakes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "visitor_event_attendance",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    ChapterId = table.Column<Guid>(type: "uuid", nullable: false),
                    RegistrationId = table.Column<Guid>(type: "uuid", nullable: false),
                    EventId = table.Column<Guid>(type: "uuid", nullable: false),
                    VerifiedByUserId = table.Column<Guid>(type: "uuid", nullable: false),
                    VerifiedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_visitor_event_attendance", x => x.Id);
                    table.ForeignKey(
                        name: "FK_visitor_event_attendance_network_free_events_EventId",
                        column: x => x.EventId,
                        principalSchema: "public",
                        principalTable: "network_free_events",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_visitor_event_attendance_organisation_units_ChapterId",
                        column: x => x.ChapterId,
                        principalSchema: "public",
                        principalTable: "organisation_units",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_visitor_event_attendance_visitor_registrations_Registration~",
                        column: x => x.RegistrationId,
                        principalSchema: "public",
                        principalTable: "visitor_registrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "visitor_follow_ups",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    ChapterId = table.Column<Guid>(type: "uuid", nullable: false),
                    RegistrationId = table.Column<Guid>(type: "uuid", nullable: false),
                    AssignedUserId = table.Column<Guid>(type: "uuid", nullable: false),
                    Outcome = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    Notes = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: false),
                    CreatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    Version = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_visitor_follow_ups", x => x.Id);
                    table.ForeignKey(
                        name: "FK_visitor_follow_ups_organisation_units_ChapterId",
                        column: x => x.ChapterId,
                        principalSchema: "public",
                        principalTable: "organisation_units",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_visitor_follow_ups_visitor_registrations_RegistrationId",
                        column: x => x.RegistrationId,
                        principalSchema: "public",
                        principalTable: "visitor_registrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "visitor_intake_links",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    ChapterId = table.Column<Guid>(type: "uuid", nullable: false),
                    RegistrationId = table.Column<Guid>(type: "uuid", nullable: false),
                    IntakeId = table.Column<Guid>(type: "uuid", nullable: false),
                    LinkedByUserId = table.Column<Guid>(type: "uuid", nullable: false),
                    LinkedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_visitor_intake_links", x => x.Id);
                    table.ForeignKey(
                        name: "FK_visitor_intake_links_member_intakes_IntakeId",
                        column: x => x.IntakeId,
                        principalSchema: "public",
                        principalTable: "member_intakes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_visitor_intake_links_visitor_registrations_RegistrationId",
                        column: x => x.RegistrationId,
                        principalSchema: "public",
                        principalTable: "visitor_registrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "visitor_invitations",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    TenantId = table.Column<Guid>(type: "uuid", nullable: false),
                    InviterMemberId = table.Column<Guid>(type: "uuid", nullable: false),
                    ChapterId = table.Column<Guid>(type: "uuid", nullable: false),
                    VisitorRegistrationId = table.Column<Guid>(type: "uuid", nullable: true),
                    Reference = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    FirstName = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    LastName = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    CompanyName = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    Email = table.Column<string>(type: "character varying(254)", maxLength: 254, nullable: false),
                    Mobile = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    IdempotencyKey = table.Column<string>(type: "character varying(120)", maxLength: 120, nullable: false),
                    Status = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    CreatedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    ExpiresAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_visitor_invitations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_visitor_invitations_members_InviterMemberId",
                        column: x => x.InviterMemberId,
                        principalSchema: "public",
                        principalTable: "members",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_visitor_invitations_organisation_units_ChapterId",
                        column: x => x.ChapterId,
                        principalSchema: "public",
                        principalTable: "organisation_units",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_visitor_invitations_visitor_registrations_VisitorRegistrati~",
                        column: x => x.VisitorRegistrationId,
                        principalSchema: "public",
                        principalTable: "visitor_registrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_event_rsvps_EventId_MemberId",
                schema: "public",
                table: "event_rsvps",
                columns: new[] { "EventId", "MemberId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_membership_registration_links_IntakeId",
                schema: "public",
                table: "membership_registration_links",
                column: "IntakeId");

            migrationBuilder.CreateIndex(
                name: "IX_membership_registration_links_RegistrationId",
                schema: "public",
                table: "membership_registration_links",
                column: "RegistrationId");

            migrationBuilder.CreateIndex(
                name: "IX_membership_registration_links_TenantId_ApplicantUserId",
                schema: "public",
                table: "membership_registration_links",
                columns: new[] { "TenantId", "ApplicantUserId" });

            migrationBuilder.CreateIndex(
                name: "IX_membership_registration_links_TenantId_IntakeId",
                schema: "public",
                table: "membership_registration_links",
                columns: new[] { "TenantId", "IntakeId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_membership_registration_links_TenantId_RegistrationId",
                schema: "public",
                table: "membership_registration_links",
                columns: new[] { "TenantId", "RegistrationId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_conversion_credits_IntakeId",
                schema: "public",
                table: "visitor_conversion_credits",
                column: "IntakeId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_conversion_credits_TenantId_ChapterId_ActivatedAt",
                schema: "public",
                table: "visitor_conversion_credits",
                columns: new[] { "TenantId", "ChapterId", "ActivatedAt" });

            migrationBuilder.CreateIndex(
                name: "IX_visitor_conversion_credits_TenantId_IntakeId",
                schema: "public",
                table: "visitor_conversion_credits",
                columns: new[] { "TenantId", "IntakeId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_conversion_credits_TenantId_InvitationId",
                schema: "public",
                table: "visitor_conversion_credits",
                columns: new[] { "TenantId", "InvitationId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_conversion_credits_TenantId_InviterMemberId_Activat~",
                schema: "public",
                table: "visitor_conversion_credits",
                columns: new[] { "TenantId", "InviterMemberId", "ActivatedAt" });

            migrationBuilder.CreateIndex(
                name: "IX_visitor_conversion_credits_TenantId_MemberId",
                schema: "public",
                table: "visitor_conversion_credits",
                columns: new[] { "TenantId", "MemberId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_conversion_credits_TenantId_RegistrationId",
                schema: "public",
                table: "visitor_conversion_credits",
                columns: new[] { "TenantId", "RegistrationId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_event_attendance_ChapterId",
                schema: "public",
                table: "visitor_event_attendance",
                column: "ChapterId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_event_attendance_EventId",
                schema: "public",
                table: "visitor_event_attendance",
                column: "EventId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_event_attendance_RegistrationId",
                schema: "public",
                table: "visitor_event_attendance",
                column: "RegistrationId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_event_attendance_TenantId_ChapterId_VerifiedAt",
                schema: "public",
                table: "visitor_event_attendance",
                columns: new[] { "TenantId", "ChapterId", "VerifiedAt" });

            migrationBuilder.CreateIndex(
                name: "IX_visitor_event_attendance_TenantId_RegistrationId_EventId",
                schema: "public",
                table: "visitor_event_attendance",
                columns: new[] { "TenantId", "RegistrationId", "EventId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_follow_ups_ChapterId",
                schema: "public",
                table: "visitor_follow_ups",
                column: "ChapterId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_follow_ups_RegistrationId",
                schema: "public",
                table: "visitor_follow_ups",
                column: "RegistrationId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_follow_ups_TenantId_ChapterId_UpdatedAt",
                schema: "public",
                table: "visitor_follow_ups",
                columns: new[] { "TenantId", "ChapterId", "UpdatedAt" });

            migrationBuilder.CreateIndex(
                name: "IX_visitor_intake_links_IntakeId",
                schema: "public",
                table: "visitor_intake_links",
                column: "IntakeId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_intake_links_RegistrationId",
                schema: "public",
                table: "visitor_intake_links",
                column: "RegistrationId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_intake_links_TenantId_ChapterId_LinkedAt",
                schema: "public",
                table: "visitor_intake_links",
                columns: new[] { "TenantId", "ChapterId", "LinkedAt" });

            migrationBuilder.CreateIndex(
                name: "IX_visitor_intake_links_TenantId_IntakeId",
                schema: "public",
                table: "visitor_intake_links",
                columns: new[] { "TenantId", "IntakeId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_intake_links_TenantId_RegistrationId",
                schema: "public",
                table: "visitor_intake_links",
                columns: new[] { "TenantId", "RegistrationId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_invitations_ChapterId",
                schema: "public",
                table: "visitor_invitations",
                column: "ChapterId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_invitations_InviterMemberId",
                schema: "public",
                table: "visitor_invitations",
                column: "InviterMemberId");

            migrationBuilder.CreateIndex(
                name: "IX_visitor_invitations_Reference",
                schema: "public",
                table: "visitor_invitations",
                column: "Reference",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_invitations_TenantId_ChapterId_CreatedAt",
                schema: "public",
                table: "visitor_invitations",
                columns: new[] { "TenantId", "ChapterId", "CreatedAt" });

            migrationBuilder.CreateIndex(
                name: "IX_visitor_invitations_TenantId_InviterMemberId_IdempotencyKey",
                schema: "public",
                table: "visitor_invitations",
                columns: new[] { "TenantId", "InviterMemberId", "IdempotencyKey" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_visitor_invitations_VisitorRegistrationId",
                schema: "public",
                table: "visitor_invitations",
                column: "VisitorRegistrationId",
                unique: true,
                filter: "\"VisitorRegistrationId\" IS NOT NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "event_rsvps",
                schema: "public");

            migrationBuilder.DropTable(
                name: "membership_registration_links",
                schema: "public");

            migrationBuilder.DropTable(
                name: "organisation_handovers",
                schema: "public");

            migrationBuilder.DropTable(
                name: "system_branding",
                schema: "public");

            migrationBuilder.DropTable(
                name: "visitor_conversion_credits",
                schema: "public");

            migrationBuilder.DropTable(
                name: "visitor_event_attendance",
                schema: "public");

            migrationBuilder.DropTable(
                name: "visitor_follow_ups",
                schema: "public");

            migrationBuilder.DropTable(
                name: "visitor_intake_links",
                schema: "public");

            migrationBuilder.DropTable(
                name: "visitor_invitations",
                schema: "public");

            migrationBuilder.DropColumn(
                name: "SectorId",
                schema: "public",
                table: "dbn_member_registrations");

            migrationBuilder.DropColumn(
                name: "SectorName",
                schema: "public",
                table: "dbn_member_registrations");

            migrationBuilder.DropColumn(
                name: "SegmentId",
                schema: "public",
                table: "dbn_member_registrations");

            migrationBuilder.DropColumn(
                name: "SegmentName",
                schema: "public",
                table: "dbn_member_registrations");

            migrationBuilder.DropColumn(
                name: "SpecialisationId",
                schema: "public",
                table: "dbn_member_registrations");

            migrationBuilder.DropColumn(
                name: "SpecialisationName",
                schema: "public",
                table: "dbn_member_registrations");

            migrationBuilder.DropColumn(
                name: "image",
                schema: "public",
                table: "chapters");

            migrationBuilder.DropColumn(
                name: "logo",
                schema: "public",
                table: "chapters");

            migrationBuilder.DropColumn(
                name: "action_reason",
                schema: "public",
                table: "chapter_leaders");

            migrationBuilder.DropColumn(
                name: "relieved_at",
                schema: "public",
                table: "chapter_leaders");

            migrationBuilder.DropColumn(
                name: "suspended_at",
                schema: "public",
                table: "chapter_leaders");
        }
    }
}
